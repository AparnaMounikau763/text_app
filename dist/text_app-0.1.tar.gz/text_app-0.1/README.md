# Text App

Simple text processing app with pytest testing.
